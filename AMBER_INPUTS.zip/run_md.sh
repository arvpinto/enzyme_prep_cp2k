#!/usr/bin/env bash
#
# run_md.sh - run the Amber minimization / heating / NPT / production protocol
#
# Usage:
#   ./run_md.sh -p complex.prmtop -c complex.rst7 [-e pmemd.cuda] [-s "min1 min2 heat npt prod"] [-n 0]
#
# Options:
#   -p  topology file (prmtop)                              [required]
#   -c  initial coordinates (rst7/inpcrd from tleap)        [required]
#   -e  MD engine: pmemd.cuda, pmemd.MPI, pmemd, sander     [default: pmemd.cuda]
#   -s  stages to run, in order (names of the *.in files)  [default: "min1 min2 heat npt prod"]
#   -n  number of MPI tasks for *.MPI engines (0 = none)    [default: 0]
#   -l  override nstlim/maxcyc of every stage (quick test)  [default: unset]
#   -h  show this help
#
# Each stage reads <stage>.in and writes <stage>.out, <stage>.rst7, <stage>.nc
# (MD stages) and <stage>.mdinfo. Stages with ntr=1 are restrained to the
# coordinates of the previous stage (-ref).

set -euo pipefail

PRMTOP=""
INPCRD=""
ENGINE="pmemd.cuda"
STAGES="min1 min2 heat npt prod"
NMPI=0
NSTEPS=""

usage() { sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'; exit "${1:-0}"; }

while getopts "p:c:e:s:n:l:h" opt; do
    case $opt in
        p) PRMTOP=$OPTARG ;;
        c) INPCRD=$OPTARG ;;
        e) ENGINE=$OPTARG ;;
        s) STAGES=$OPTARG ;;
        n) NMPI=$OPTARG ;;
        l) NSTEPS=$OPTARG ;;
        h) usage 0 ;;
        *) usage 1 ;;
    esac
done

[[ -z "$PRMTOP" || -z "$INPCRD" ]] && { echo "ERROR: -p and -c are required"; usage 1; }
[[ -f "$PRMTOP" ]] || { echo "ERROR: $PRMTOP not found"; exit 1; }
[[ -f "$INPCRD" ]] || { echo "ERROR: $INPCRD not found"; exit 1; }
command -v "$ENGINE" > /dev/null || { echo "ERROR: $ENGINE not found in PATH"; exit 1; }

RUN="$ENGINE"
if [[ "$NMPI" -gt 0 ]]; then
    RUN="mpirun -np $NMPI $ENGINE"
fi

PREV="$INPCRD"
for STAGE in $STAGES; do
    IN="$STAGE.in"
    [[ -f "$IN" ]] || { echo "ERROR: $IN not found"; exit 1; }

    # optional quick-test override of the number of steps
    if [[ -n "$NSTEPS" ]]; then
        sed -E -e "s/nstlim=[0-9]+/nstlim=$NSTEPS/" -e "s/maxcyc=[0-9]+/maxcyc=$NSTEPS/" \
               -e "s/ncyc=[0-9]+/ncyc=$((NSTEPS / 2))/" "$IN" > "${STAGE}_test.in"
        IN="${STAGE}_test.in"
    fi

    ARGS=(-O -i "$IN" -o "$STAGE.out" -p "$PRMTOP" -c "$PREV" -r "$STAGE.rst7" -inf "$STAGE.mdinfo")
    grep -q "imin=0" "$IN" && ARGS+=(-x "$STAGE.nc")
    grep -q "ntr=1" "$IN" && ARGS+=(-ref "$PREV")

    echo "[$(date '+%F %T')] running $STAGE with $ENGINE (input: $PREV)"
    $RUN "${ARGS[@]}"
    PREV="$STAGE.rst7"
done

echo "[$(date '+%F %T')] done. Last restart file: $PREV"
