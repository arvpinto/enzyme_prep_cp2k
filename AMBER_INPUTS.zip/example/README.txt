Files of the worked example (human alpha-thrombin + lig_5, Sections I and II).

lig_5.sdf          ligand coordinates (OpenFF protein-ligand benchmark, thrombin set, PDB 2ZFF)
LIG.mol2           antechamber output (GAFF2, AM1-BCC, net charge +1)
LIG_fixed.mol2     charges corrected to sum to +1 (mol2_charge_fix.py)
LIG.frcmod         parmchk2 output
protein_amber.pdb  protein after pdb_reres, pdb4amber --nohyd, HIS tautomers set, CONECT removed
residue_map.txt    original (chymotrypsin) numbering -> sequential numbering

To rebuild the system:
  NWAT=$(tleap -f tleap_dry.in | grep "Added" | awk '{print $2}')
  NIONS=$(python3 -c "print(round(0.15*$NWAT/55.5))")
  sed "s/NIONS/$NIONS/g" tleap.in > tleap_run.in
  tleap -f tleap_run.in > tleap.log
(run from a folder containing tleap*.in and the files above)
