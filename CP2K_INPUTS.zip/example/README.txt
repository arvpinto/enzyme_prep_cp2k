Files generated for the worked example (Sections IV to VI), for comparison with your own runs.

type_renaming.dat         atom types renamed by prmtop_fix_types.py (complex.prmtop -> AMBER.prmtop)
forceeval_qmmm.cp2k.inc   &CELL, &QM_KIND and &LINK (include inside &QMMM)
kinds.cp2k.inc            &KIND sections for AMBER.prmtop (include inside &SUBSYS)
kinds_ee.cp2k.inc         &KIND sections for AMBER_ee.prmtop (include inside &SUBSYS)
charge_correction.parmed  ParmEd script that writes AMBER_ee.prmtop from AMBER.prmtop
qm_region.xyz             QM region with the capping hydrogens
qmmm_setup_summary.txt    full output of cp2k_qmmm_setup.py
ewald_scan.dat            output of cp2k_ewald_scan.sh

The topologies and coordinates (about 8 MB each) are not included; rebuild them with
the inputs of AMBER_INPUTS.zip.
